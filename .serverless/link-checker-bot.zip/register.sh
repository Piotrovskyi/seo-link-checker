curl -F "url=https://syprx7m2hl.execute-api.eu-west-1.amazonaws.com/dev/link-checker-bot" https://api.telegram.org/bot2093000892:AAEGZd26QueCsUcjtsIJ6tTcxPoU8hlHd1w/setWebhook
